package com.example.snm.retrofig;




import java.util.HashMap;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by snm on 2016/6/23.
 */
public interface APIService {

    @GET("index.php")
    Call<ResponseBody> getIpInfo(@Query("act") String act , @Query("op") String op);

    @GET("index.php")
    Call<ResponseBody> getIpInfo(@Query("act") String act , @Query("op") String op,@Query("key") String key);

    @POST("index.php")
    Call<ResponseBody> postIpInfo(@Query("act") String act , @Query("op") String op , @Query("city_name") String city_name);

    @FormUrlEncoded
    @POST("index.php")
    Call<ResponseBody> postIpInfo(@FieldMap HashMap<String, String> map);
}
