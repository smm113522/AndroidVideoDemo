package com.example.snm.retrofig;

/**
 * Created by snm on 2016/6/23.
 */
public class GetIpInfoResponse {
}
