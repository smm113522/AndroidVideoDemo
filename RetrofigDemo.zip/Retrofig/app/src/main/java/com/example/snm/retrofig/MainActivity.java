package com.example.snm.retrofig;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import java.io.IOException;


import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

//    @BindView(R.id.getdate) Button getDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        ButterKnife.bind(this);
        findViewById(R.id.getdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getResultDate();
                APIServiceImpl.postCallTrunList1().enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        try {
                            Toast.makeText(getApplicationContext(),response.body().string(),Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });
            }
        });
    }
    private Handler handler =new Handler(){
        @Override
//当有消息发送出来的时候就执行Handler的这个方法
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            getDate();
//处理UI
        }
    };
// 同步进行的
    public void getDate(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http:///")
                .build();
        APIService apiService = retrofit.create(APIService.class);

        Call<ResponseBody> call = apiService.getIpInfo("","");
        try {
            Response<ResponseBody> bodyResponse = call.execute();
            String body = bodyResponse.body().string();//获取返回体的字符串
            Toast.makeText(getApplicationContext(),body,Toast.LENGTH_SHORT).show();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
//   异步进行的
    public void getResultDate(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http:")
                .build();
        APIService apiService = retrofit.create(APIService.class);

        Call<ResponseBody> call = apiService.getIpInfo("","getcitylist");

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    Toast.makeText(getApplicationContext(),response.body().string(),Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });



    }

}
