package com.example.snm.retrofig;




import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.HashMap;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;

/**
 * Created by snm on 2016/6/23.
 */
public class APIServiceImpl {
   public static APIService apiService;
    private static OkHttpClient mOkHttpClient;

//    get 没有参数的
    public static Call<ResponseBody> getCall(){
        Call<ResponseBody> call = getAPIService().getIpInfo(" "," ");
        return call;
    }
//    index.php?act=member_turn&op=turn_list
//    get 有参数的 多参数无所谓的
    public static Call<ResponseBody> getCallTrunList(){
        Call<ResponseBody> call = getAPIService().getIpInfo(" "," ","dddd");
        return call;
    }
//    act=city&op=setcitybyname
    public static Call<ResponseBody> postCallTrunList(){
        Call<ResponseBody> call = getAPIService().postIpInfo(" "," ","天津市");
        return call;
    }
    public static Call<ResponseBody> postCallTrunList1(){
        HashMap<String, String> params = new HashMap<String, String>();
        params.put(" ", "city");
        params.put(" ", "setcitybyname");
        params.put(" ", "天津市");
        Call<ResponseBody> call = getAPIService().postIpInfo(params);
        return call;
    }
//    public static HashMap<String, String> params ;
//    public static HashMap<String, String>  getHashMap(){
//        if(params == null){
//            params = new HashMap<String, String>();
//        }
//        return params;
//    }

    public static APIService getAPIService(){
        if(apiService == null){
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("http://123.57.130./ / /")
                    .client(OkHttpUtil())
                    .build();
            apiService = retrofit.create(APIService.class);
        }
        return apiService;
    }
    public static OkHttpClient OkHttpUtil() {
        if(mOkHttpClient == null){
            mOkHttpClient = new OkHttpClient();
        }
        return mOkHttpClient;
    }


}
